# Nexa Music — Luxury Brazilian Edition

Aplicativo Android com identidade visual premium e descoberta de música brasileira.

## Incluído nesta versão
- Interface exclusiva preta/roxa com hero editorial e cartões de gêneros.
- Busca por termos brasileiros e atalhos para funk BR/SP/RJ, sertanejo, reggae, pagode, trap, piseiro e MPB.
- Catálogo online consultado pela API pública do Audius.
- Capas, favoritos em memória e player com barra de progresso, tempo decorrido e duração.
- Avanço/retrocesso no player conforme a fila disponível.

## Limitações do MVP
- A API do Audius fornece acesso ao catálogo aberto; não garante repertório comercial de artistas específicos nem todos os lançamentos brasileiros.
- A curadoria "Brasil em Alta" nesta versão é uma busca no catálogo, não um ranking editorial verificado de lançamentos do Brasil.
- Favoritos ainda não persistem depois de fechar o app.
- Reprodução em segundo plano e controles na tela bloqueada ainda não estão implementados.
- Não há login nem Firebase nesta versão, conforme decisão do produto.

## Build
O workflow do GitHub Actions deve extrair este ZIP e executar `gradle assembleDebug`.
