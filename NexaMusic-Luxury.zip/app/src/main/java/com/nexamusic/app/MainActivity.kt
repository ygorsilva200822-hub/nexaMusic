package com.nexamusic.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import coil.compose.AsyncImage
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

private val Ink = Color(0xFF08070D)
private val SurfaceA = Color(0xFF171421)
private val SurfaceB = Color(0xFF211A31)
private val Violet = Color(0xFF9B5CFF)
private val VioletLight = Color(0xFFC7A2FF)
private val TextMain = Color(0xFFF7F3FF)
private val TextSoft = Color(0xFFA9A2B7)

private data class Genre(val title: String, val query: String, val tag: String)

class MainActivity : ComponentActivity() {
    private var player: ExoPlayer? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        player = ExoPlayer.Builder(this).build()
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(
                background = Ink, surface = SurfaceA, primary = Violet,
                onBackground = TextMain, onSurface = TextMain
            )) {
                NexaLuxuryScreen(
                    player = player!!,
                    onPlay = { track ->
                        player?.setMediaItem(MediaItem.fromUri(track.streamUrl))
                        player?.prepare()
                        player?.play()
                    }
                )
            }
        }
    }

    override fun onDestroy() {
        player?.release()
        player = null
        super.onDestroy()
    }
}

@Composable
private fun NexaLuxuryScreen(player: ExoPlayer, onPlay: (Track) -> Unit) {
    val genres = listOf(
        Genre("Funk BR", "funk brasileiro", "01"),
        Genre("Funk SP", "funk paulista", "02"),
        Genre("Funk RJ", "funk carioca", "03"),
        Genre("Sertanejo", "sertanejo brasileiro", "04"),
        Genre("Reggae", "reggae brasileiro", "05"),
        Genre("Pagode", "pagode brasileiro", "06"),
        Genre("Trap BR", "trap brasileiro", "07"),
        Genre("Piseiro", "piseiro brasileiro", "08"),
        Genre("MPB", "MPB brasileira", "09")
    )
    var query by remember { mutableStateOf("funk brasileiro") }
    var selectedGenre by remember { mutableStateOf("Funk BR") }
    var tracks by remember { mutableStateOf<List<Track>>(emptyList()) }
    var favorites by remember { mutableStateOf(setOf<String>()) }
    var current by remember { mutableStateOf<Track?>(null) }
    var loading by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf<String?>(null) }
    var playing by remember { mutableStateOf(false) }
    var duration by remember { mutableLongStateOf(0L) }
    var position by remember { mutableLongStateOf(0L) }
    val scope = rememberCoroutineScope()

    fun search(term: String) {
        query = term
        loading = true
        message = null
        scope.launch {
            try {
                tracks = AudiusApi.searchBrazilian(term)
                if (tracks.isEmpty()) message = "Nenhuma faixa encontrada para essa busca. Experimente outro estilo."
            } catch (_: Exception) {
                message = "Não foi possível acessar o catálogo. Confira sua conexão e tente novamente."
            } finally {
                loading = false
            }
        }
    }

    LaunchedEffect(Unit) { search("funk brasileiro") }

    LaunchedEffect(player) {
        while (true) {
            playing = player.isPlaying
            duration = player.duration.coerceAtLeast(0L)
            position = player.currentPosition.coerceAtLeast(0L)
            delay(500)
        }
    }

    Column(
        Modifier.fillMaxSize().background(
            Brush.verticalGradient(listOf(Color(0xFF151020), Ink, Ink))
        )
    ) {
        Row(
            Modifier.fillMaxWidth().padding(start = 22.dp, end = 22.dp, top = 18.dp, bottom = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                Text("N E X A", color = VioletLight, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 5.sp)
                Text("MUSIC", color = TextMain, fontSize = 29.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 1.sp)
            }
            Box(
                Modifier.size(42.dp).clip(CircleShape)
                    .background(Brush.linearGradient(listOf(Violet, Color(0xFF4B287B))))
                    .border(1.dp, VioletLight.copy(alpha = .5f), CircleShape),
                contentAlignment = Alignment.Center
            ) { Text("N", color = Color.White, fontWeight = FontWeight.Black, fontSize = 20.sp) }
        }

        LazyColumn(
            modifier = Modifier.weight(1f),
            contentPadding = PaddingValues(start = 20.dp, end = 20.dp, bottom = 18.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                Box(
                    Modifier.fillMaxWidth().height(174.dp).clip(RoundedCornerShape(24.dp))
                        .background(Brush.linearGradient(listOf(Color(0xFF4D267D), Color(0xFF21162F), Color(0xFF100E18))))
                        .border(1.dp, Violet.copy(alpha = .38f), RoundedCornerShape(24.dp))
                        .padding(20.dp)
                ) {
                    Column(Modifier.align(Alignment.CenterStart)) {
                        Text("CURADORIA BRASILEIRA", color = VioletLight, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                        Spacer(Modifier.height(8.dp))
                        Text("O som do Brasil.", color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.ExtraBold)
                        Text("Seu ritmo. Sua identidade.", color = Color.White.copy(alpha = .78f), fontSize = 13.sp)
                        Spacer(Modifier.height(12.dp))
                        Text("BRASIL EM ALTA  •  NEXA", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    }
                    Text("♫", Modifier.align(Alignment.BottomEnd), color = VioletLight.copy(alpha = .35f), fontSize = 76.sp)
                }
            }
            item {
                Row(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp))
                        .background(SurfaceA).border(1.dp, Violet.copy(alpha = .25f), RoundedCornerShape(16.dp))
                        .padding(horizontal = 14.dp, vertical = 13.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.Search, null, tint = VioletLight)
                    Spacer(Modifier.width(10.dp))
                    BasicTextField(
                        value = query, onValueChange = { query = it },
                        modifier = Modifier.weight(1f),
                        singleLine = true,
                        textStyle = androidx.compose.ui.text.TextStyle(color = TextMain, fontSize = 14.sp),
                        decorationBox = { inner ->
                            if (query.isEmpty()) Text("Buscar música ou artista", color = TextSoft, fontSize = 14.sp)
                            inner()
                        }
                    )
                    Text("BUSCAR", color = VioletLight, fontSize = 11.sp, fontWeight = FontWeight.ExtraBold,
                        modifier = Modifier.clickable { search(query) }.padding(start = 8.dp))
                }
            }
            item {
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("ESCOLHA SEU CLIMA", color = TextMain, fontSize = 13.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                        Spacer(Modifier.weight(1f))
                        Text("BRASIL", color = VioletLight, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    }
                    Spacer(Modifier.height(10.dp))
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(genres) { genre ->
                            val selected = selectedGenre == genre.title
                            Column(
                                Modifier.width(104.dp).clip(RoundedCornerShape(15.dp))
                                    .background(if (selected) Brush.linearGradient(listOf(Color(0xFF7540B5), Color(0xFF3A2357))) else Brush.linearGradient(listOf(SurfaceB, SurfaceA)))
                                    .border(1.dp, if (selected) VioletLight.copy(alpha = .8f) else Color.White.copy(alpha = .07f), RoundedCornerShape(15.dp))
                                    .clickable { selectedGenre = genre.title; search(genre.query) }
                                    .padding(12.dp)
                            ) {
                                Text(genre.tag, color = VioletLight, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                Spacer(Modifier.height(8.dp))
                                Text(genre.title, color = TextMain, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
            item {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("BRASIL EM ALTA", color = TextMain, fontSize = 18.sp, fontWeight = FontWeight.ExtraBold)
                        Text("Resultados do catálogo aberto", color = TextSoft, fontSize = 11.sp)
                    }
                    if (loading) CircularProgressIndicator(Modifier.size(20.dp), color = Violet, strokeWidth = 2.dp)
                }
            }
            if (message != null) {
                item { Text(message!!, color = TextSoft, fontSize = 13.sp, modifier = Modifier.padding(vertical = 12.dp)) }
            }
            items(tracks, key = { it.id }) { track ->
                Row(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(17.dp))
                        .background(SurfaceA).border(1.dp, Color.White.copy(alpha = .06f), RoundedCornerShape(17.dp))
                        .clickable { current = track; onPlay(track) }
                        .padding(11.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    AsyncImage(
                        model = track.artwork, contentDescription = "Capa de ${track.title}",
                        modifier = Modifier.size(58.dp).clip(RoundedCornerShape(11.dp)).background(SurfaceB)
                    )
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(track.title, color = TextMain, fontSize = 14.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Spacer(Modifier.height(4.dp))
                        Text(track.artist, color = TextSoft, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                    IconButton(onClick = {
                        favorites = if (favorites.contains(track.id)) favorites - track.id else favorites + track.id
                    }) {
                        Icon(if (favorites.contains(track.id)) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                            null, tint = if (favorites.contains(track.id)) VioletLight else TextSoft)
                    }
                }
            }
        }

        current?.let { track ->
            Column(
                Modifier.fillMaxWidth().background(SurfaceA)
                    .border(width = 1.dp, color = Violet.copy(alpha = .28f))
                    .padding(horizontal = 18.dp, vertical = 12.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    AsyncImage(track.artwork, null, Modifier.size(42.dp).clip(RoundedCornerShape(9.dp)).background(SurfaceB))
                    Spacer(Modifier.width(10.dp))
                    Column(Modifier.weight(1f)) {
                        Text(track.title, color = TextMain, fontWeight = FontWeight.Bold, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(track.artist, color = TextSoft, fontSize = 11.sp, maxLines = 1)
                    }
                    Text("NEXA PLAYER", color = VioletLight, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                }
                Slider(
                    value = if (duration > 0) position.toFloat().coerceIn(0f, duration.toFloat()) else 0f,
                    onValueChange = { position = it.toLong() },
                    onValueChangeFinished = { if (duration > 0) player.seekTo(position.coerceIn(0L, duration)) },
                    valueRange = 0f..(duration.coerceAtLeast(1L).toFloat()),
                    colors = SliderDefaults.colors(
                        thumbColor = VioletLight, activeTrackColor = Violet,
                        inactiveTrackColor = Color(0xFF494253)
                    ),
                    modifier = Modifier.height(28.dp)
                )
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text(formatTime(position), color = TextSoft, fontSize = 10.sp)
                    Spacer(Modifier.weight(1f))
                    Text(formatTime(duration), color = TextSoft, fontSize = 10.sp)
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = { player.seekToPreviousMediaItem() }) {
                        Icon(Icons.Default.SkipPrevious, null, tint = TextMain)
                    }
                    IconButton(onClick = { if (player.isPlaying) player.pause() else player.play() },
                        modifier = Modifier.padding(horizontal = 12.dp).size(48.dp).clip(CircleShape).background(Violet)) {
                        Icon(if (playing) Icons.Default.Pause else Icons.Default.PlayArrow, null, tint = Color.White)
                    }
                    IconButton(onClick = { player.seekToNextMediaItem() }) {
                        Icon(Icons.Default.SkipNext, null, tint = TextMain)
                    }
                }
            }
        }
    }
}

private fun formatTime(ms: Long): String {
    if (ms <= 0L) return "0:00"
    val totalSeconds = ms / 1000
    return "%d:%02d".format(totalSeconds / 60, totalSeconds % 60)
}
