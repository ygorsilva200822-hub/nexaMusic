package com.nexamusic.app

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.net.URLEncoder
import java.util.concurrent.TimeUnit

object AudiusApi {
    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(25, TimeUnit.SECONDS)
        .build()
    private const val BASE = "https://api.audius.co/v1"

    suspend fun searchBrazilian(query: String): List<Track> = withContext(Dispatchers.IO) {
        val q = URLEncoder.encode(query, "UTF-8")
        val request = Request.Builder()
            .url("$BASE/tracks/search?query=$q&limit=30")
            .header("Accept", "application/json")
            .build()
        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) error("Catálogo indisponível (${response.code})")
            val root = JSONObject(response.body?.string() ?: "{}")
            val data = root.optJSONArray("data") ?: return@withContext emptyList()
            buildList {
                for (i in 0 until data.length()) {
                    val item = data.optJSONObject(i) ?: continue
                    val id = item.optString("id")
                    if (id.isBlank() || id == "null") continue
                    val user = item.optJSONObject("user")
                    val art = item.optJSONObject("artwork")
                    val image = art?.optString("480x480")?.takeIf { !it.isNullOrBlank() && it != "null" }
                        ?: art?.optString("150x150")?.takeIf { !it.isNullOrBlank() && it != "null" }
                    add(
                        Track(
                            id = id,
                            title = item.optString("title", "Faixa sem título"),
                            artist = user?.optString("name")?.takeIf { !it.isNullOrBlank() } ?: "Artista independente",
                            artwork = image,
                            streamUrl = "$BASE/tracks/${URLEncoder.encode(id, "UTF-8")}/stream"
                        )
                    )
                }
            }
        }
    }
}
