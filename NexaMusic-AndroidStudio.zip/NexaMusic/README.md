# Nexa Music

Player Android offline para arquivos de áudio armazenados no próprio aparelho.

## Recursos
- Biblioteca local via MediaStore
- Reprodução com Media3/ExoPlayer
- Serviço de reprodução em segundo plano e notificação de mídia
- Favoritos, aleatório e repetição
- Interface escura

## Abrir e gerar APK
1. Instale o Android Studio em um computador.
2. Extraia este ZIP e abra a pasta `NexaMusic` no Android Studio.
3. Aguarde a sincronização do Gradle (é necessária internet na primeira compilação para baixar dependências).
4. Se solicitado, instale Android SDK Platform 35 e JDK 17.
5. Selecione **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
6. O APK de depuração ficará em `app/build/outputs/apk/debug/app-debug.apk`.

## Instalar no Moto E7
Transfira `app-debug.apk` para o celular, abra o arquivo e autorize a instalação dessa fonte quando o Android solicitar. Conceda a permissão de acesso a áudio ao abrir o aplicativo.

## Compatibilidade
- minSdk 23; testado por configuração para Android 10 ou superior.
- Este ambiente não contém Android SDK/Gradle, portanto o APK não foi compilado nem testado neste pacote.
