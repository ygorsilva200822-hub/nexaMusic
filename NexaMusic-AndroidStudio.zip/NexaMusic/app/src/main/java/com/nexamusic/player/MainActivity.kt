package com.nexamusic.player

import android.Manifest
import android.content.ComponentName
import android.content.pm.PackageManager
import android.database.Cursor
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import android.app.Activity
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.google.common.util.concurrent.ListenableFuture
import java.util.concurrent.Executors

data class Song(val id: Long, val title: String, val artist: String, val uri: Uri)

class MainActivity : Activity() {
    private lateinit var root: LinearLayout
    private lateinit var list: LinearLayout
    private lateinit var nowPlaying: TextView
    private var controllerFuture: ListenableFuture<MediaController>? = null
    private var player: MediaController? = null
    private val songs = mutableListOf<Song>()
    private var favoritesOnly = false
    private val favorites = mutableSetOf<Long>()
    private val prefs by lazy { getSharedPreferences("nexa_music", MODE_PRIVATE) }

    private val permissionLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) {
        if (it) loadSongs() else toast("Permissão de áudio necessária para mostrar suas músicas.")
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        favorites.addAll(prefs.getStringSet("favorites", emptySet())!!.mapNotNull { it.toLongOrNull() })
        buildUi()
        connectController()
        checkPermissionAndLoad()
    }

    private fun buildUi() {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(22, 26, 22, 12)
            setBackgroundColor(Color.rgb(13, 16, 20))
        }
        val header = TextView(this).apply {
            text = "NEXA MUSIC"
            textSize = 25f
            setTextColor(Color.WHITE)
            setTypeface(null, android.graphics.Typeface.BOLD)
        }
        root.addView(header)
        val subtitle = TextView(this).apply {
            text = "Sua música. Sem internet."
            textSize = 14f
            setTextColor(Color.rgb(160, 170, 180))
            setPadding(0, 4, 0, 18)
        }
        root.addView(subtitle)

        val filters = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        filters.addView(makeButton("Todas") { favoritesOnly = false; renderSongs() }, weighted())
        filters.addView(makeButton("Favoritas") { favoritesOnly = true; renderSongs() }, weighted())
        filters.addView(makeButton("Atualizar") { checkPermissionAndLoad() }, weighted())
        root.addView(filters)

        val section = TextView(this).apply {
            text = "BIBLIOTECA"
            textSize = 12f
            setTextColor(Color.rgb(110, 220, 160))
            setPadding(0, 18, 0, 8)
        }
        root.addView(section)

        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val scroll = android.widget.ScrollView(this).apply { addView(list) }
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        val divider = View(this).apply { setBackgroundColor(Color.rgb(45, 52, 60)) }
        root.addView(divider, LinearLayout.LayoutParams(-1, 1))
        nowPlaying = TextView(this).apply {
            text = "Nenhuma música tocando"
            textSize = 15f
            setTextColor(Color.WHITE)
            setPadding(0, 12, 0, 10)
        }
        root.addView(nowPlaying)
        val controls = LinearLayout(this).apply {
            gravity = Gravity.CENTER
            orientation = LinearLayout.HORIZONTAL
        }
        controls.addView(makeButton("⏮") { player?.seekToPreviousMediaItem() }, weighted())
        controls.addView(makeButton("▶ / ❚❚") {
            player?.let { if (it.isPlaying) it.pause() else it.play() }
        }, weighted(1.4f))
        controls.addView(makeButton("⏭") { player?.seekToNextMediaItem() }, weighted())
        root.addView(controls)
        val modes = LinearLayout(this).apply { gravity = Gravity.CENTER }
        modes.addView(makeButton("Aleatório") {
            player?.shuffleModeEnabled = !(player?.shuffleModeEnabled ?: false)
            toast(if (player?.shuffleModeEnabled == true) "Aleatório ativado" else "Aleatório desativado")
        }, weighted())
        modes.addView(makeButton("Repetir") {
            player?.repeatMode = when (player?.repeatMode) {
                0 -> 1
                1 -> 2
                else -> 0
            }
            toast("Modo de repetição atualizado")
        }, weighted())
        root.addView(modes)
        setContentView(root)
    }

    private fun weighted(weight: Float = 1f) = LinearLayout.LayoutParams(0, -2, weight)

    private fun makeButton(label: String, action: () -> Unit): Button =
        Button(this).apply {
            text = label
            textSize = 12f
            isAllCaps = false
            setTextColor(Color.WHITE)
            setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(35, 45, 54)))
            setOnClickListener { action() }
        }

    private fun checkPermissionAndLoad() {
        val permission = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO
                         else Manifest.permission.READ_EXTERNAL_STORAGE
        if (ContextCompat.checkSelfPermission(this, permission) == PackageManager.PERMISSION_GRANTED) {
            loadSongs()
        } else permissionLauncher.launch(permission)
    }

    private fun loadSongs() {
        songs.clear()
        val collection = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        val projection = arrayOf(
            MediaStore.Audio.Media._ID,
            MediaStore.Audio.Media.TITLE,
            MediaStore.Audio.Media.ARTIST
        )
        val selection = "${MediaStore.Audio.Media.IS_MUSIC} != 0"
        val sort = "${MediaStore.Audio.Media.TITLE} COLLATE NOCASE ASC"
        val cursor: Cursor? = contentResolver.query(collection, projection, selection, null, sort)
        cursor?.use {
            val idCol = it.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
            val titleCol = it.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
            val artistCol = it.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
            while (it.moveToNext()) {
                val id = it.getLong(idCol)
                val uri = Uri.withAppendedPath(collection, id.toString())
                songs.add(Song(id, it.getString(titleCol) ?: "Faixa sem título",
                    it.getString(artistCol) ?: "Artista desconhecido", uri))
            }
        }
        renderSongs()
    }

    private fun renderSongs() {
        list.removeAllViews()
        val visible = songs.filter { !favoritesOnly || favorites.contains(it.id) }
        if (visible.isEmpty()) {
            val empty = TextView(this).apply {
                text = if (favoritesOnly) "Você ainda não favoritou nenhuma faixa." else
                    "Nenhuma música encontrada. Coloque arquivos de áudio no celular e toque em Atualizar."
                setTextColor(Color.LTGRAY)
                textSize = 14f
                setPadding(8, 24, 8, 24)
            }
            list.addView(empty)
            return
        }
        visible.forEachIndexed { index, song ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(8, 8, 4, 8)
                setBackgroundColor(if (index % 2 == 0) Color.rgb(20, 24, 29) else Color.rgb(15, 19, 24))
            }
            val info = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            info.addView(TextView(this).apply {
                text = song.title; textSize = 15f; setTextColor(Color.WHITE)
            })
            info.addView(TextView(this).apply {
                text = song.artist; textSize = 12f; setTextColor(Color.rgb(155, 165, 175))
            })
            row.addView(info, LinearLayout.LayoutParams(0, -2, 1f))
            row.addView(makeButton(if (favorites.contains(song.id)) "♥" else "♡") {
                if (!favorites.add(song.id)) favorites.remove(song.id)
                prefs.edit().putStringSet("favorites", favorites.map { it.toString() }.toSet()).apply()
                renderSongs()
            })
            row.setOnClickListener { playFrom(index, visible) }
            list.addView(row, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 3 })
        }
    }

    private fun playFrom(index: Int, queue: List<Song>) {
        val items = queue.map { song ->
            MediaItem.Builder()
                .setMediaId(song.id.toString())
                .setUri(song.uri)
                .setMediaMetadata(MediaMetadata.Builder().setTitle(song.title).setArtist(song.artist).build())
                .build()
        }
        player?.let {
            it.setMediaItems(items, index, 0L)
            it.prepare()
            it.play()
            nowPlaying.text = "Tocando: ${queue[index].title} — ${queue[index].artist}"
        } ?: toast("Preparando o reprodutor. Toque na faixa novamente.")
    }

    private fun connectController() {
        val token = SessionToken(this, ComponentName(this, MusicService::class.java))
        controllerFuture = MediaController.Builder(this, token).buildAsync()
        controllerFuture?.addListener({
            try { player = controllerFuture?.get() }
            catch (_: Exception) { toast("Não foi possível iniciar o reprodutor.") }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_SHORT).show()

    override fun onDestroy() {
        controllerFuture?.let { MediaController.releaseFuture(it) }
        player = null
        super.onDestroy()
    }
}
