package com.nexamusic.app

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.net.URLEncoder
import java.util.concurrent.TimeUnit

object MusicCatalog {
    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(25, TimeUnit.SECONDS)
        .build()

    suspend fun search(query: String): List<Track> = withContext(Dispatchers.IO) {
        val deezer = runCatching { searchDeezer(query) }.getOrDefault(emptyList())
        val audius = runCatching { searchAudius(query) }.getOrDefault(emptyList())
        (deezer + audius).distinctBy { it.id }.take(50)
    }

    private fun get(url: String): String {
        val request = Request.Builder().url(url).header("Accept", "application/json").build()
        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) error("HTTP ${response.code}")
            return response.body?.string() ?: "{}"
        }
    }

    private fun searchDeezer(query: String): List<Track> {
        val q = URLEncoder.encode(query, "UTF-8")
        val root = JSONObject(get("https://api.deezer.com/search?q=$q&limit=25"))
        val data = root.optJSONArray("data") ?: return emptyList()
        return buildList {
            for (i in 0 until data.length()) {
                val item = data.optJSONObject(i) ?: continue
                val preview = item.optString("preview")
                if (preview.isBlank() || preview == "null") continue
                val artist = item.optJSONObject("artist")
                val album = item.optJSONObject("album")
                val id = item.optString("id")
                if (id.isBlank() || id == "null") continue
                add(Track(
                    id = "deezer:$id",
                    title = item.optString("title", "Faixa sem título"),
                    artist = artist?.optString("name")?.takeIf { it.isNotBlank() } ?: "Artista",
                    artwork = album?.optString("cover_xl")?.takeIf { it.isNotBlank() && it != "null" }
                        ?: album?.optString("cover_big")?.takeIf { it.isNotBlank() && it != "null" },
                    streamUrl = preview,
                    source = "DEEZER",
                    isPreview = true
                ))
            }
        }
    }

    private fun searchAudius(query: String): List<Track> {
        val q = URLEncoder.encode(query, "UTF-8")
        val root = JSONObject(get("https://api.audius.co/v1/tracks/search?query=$q&limit=25"))
        val data = root.optJSONArray("data") ?: return emptyList()
        return buildList {
            for (i in 0 until data.length()) {
                val item = data.optJSONObject(i) ?: continue
                val id = item.optString("id")
                if (id.isBlank() || id == "null") continue
                val user = item.optJSONObject("user")
                val art = item.optJSONObject("artwork")
                val image = art?.optString("480x480")?.takeIf { !it.isNullOrBlank() && it != "null" }
                    ?: art?.optString("150x150")?.takeIf { !it.isNullOrBlank() && it != "null" }
                add(Track(
                    id = "audius:$id",
                    title = item.optString("title", "Faixa sem título"),
                    artist = user?.optString("name")?.takeIf { !it.isNullOrBlank() } ?: "Artista independente",
                    artwork = image,
                    streamUrl = "https://api.audius.co/v1/tracks/${URLEncoder.encode(id, "UTF-8")}/stream",
                    source = "AUDIUS",
                    isPreview = false
                ))
            }
        }
    }
}
