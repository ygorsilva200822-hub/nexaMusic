# Nexa Music — versão catálogo duplo

Aplicativo Android em Kotlin/Jetpack Compose, sem cadastro obrigatório e sem Firebase.

## Fontes de música
- Deezer: pesquisa de catálogo, capas e prévias de 30 segundos quando fornecidas pela API.
- Audius: pesquisa e reprodução de faixas disponibilizadas no catálogo aberto, quando a faixa permite streaming.

A tela identifica claramente a fonte e se a faixa é prévia ou completa. A disponibilidade varia por música, país e regras dos provedores. Não há garantia de que todo artista ou lançamento esteja disponível.

## Limitações desta versão
- As prévias Deezer têm 30 segundos; não são músicas completas.
- Audius pode não ter músicas de grandes artistas comerciais.
- Favoritos permanecem apenas durante a sessão.
- Ainda não há reprodução em segundo plano nem controles na tela bloqueada.
- O player não inclui uma fila persistente entre sessões.

## Build
Abra o projeto no Android Studio e execute `gradle assembleDebug`, ou use o workflow do GitHub Actions.
