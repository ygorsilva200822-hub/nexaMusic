# Nexa Music — primeira versão Android
Projeto nativo Kotlin + Jetpack Compose. Inclui busca no catálogo Audius, reprodução de faixas via endpoint oficial, Media3 MediaSession e favoritos temporários na sessão.
Para compilar: Android SDK 35 + Java 17 + Gradle 8.9; executar `gradle assembleDebug`.
APK: `app/build/outputs/apk/debug/app-debug.apk`.
O catálogo e a reprodução estão sujeitos aos termos da Audius e aos direitos/permissões de cada faixa. Favoritos e playlists persistentes ainda são etapas futuras.
