package com.nexa.music
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.net.URLEncoder

class AudiusRepository {
    private val client = OkHttpClient()
    private val hosts = listOf("https://api.audius.co/v1", "https://discoveryprovider.audius.co/v1")
    suspend fun search(query:String):List<Track> = withContext(Dispatchers.IO) {
        for (host in hosts) {
            try {
                val url = "$host/tracks/search?query=${URLEncoder.encode(query,"UTF-8")}&limit=30"
                client.newCall(Request.Builder().url(url).build()).execute().use { r ->
                    if (r.isSuccessful) {
                        val arr = JSONObject(r.body?.string() ?: "{}").optJSONArray("data") ?: return@use
                        val out = mutableListOf<Track>()
                        for (i in 0 until arr.length()) {
                            val o=arr.optJSONObject(i) ?: continue
                            val art=o.optJSONObject("artwork")
                            val image=art?.optString("480x480")?.takeIf { !it.isNullOrBlank() && it!="null" }
                                ?: art?.optString("150x150")?.takeIf { !it.isNullOrBlank() && it!="null" }
                            out.add(Track(o.optString("id"),o.optString("title","Faixa sem título"),
                                o.optJSONObject("user")?.optString("name") ?: "Artista independente",image,o.optLong("duration")))
                        }
                        if(out.isNotEmpty()) return@withContext out
                    }
                }
            } catch (_:Exception) {}
        }
        emptyList()
    }
    fun streamUrl(track:Track)="https://api.audius.co/v1/tracks/${track.id}/stream"
}
