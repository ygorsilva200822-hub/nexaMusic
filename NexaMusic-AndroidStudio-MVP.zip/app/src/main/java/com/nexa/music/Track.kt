package com.nexa.music
data class Track(val id:String, val title:String, val artist:String, val artwork:String?, val duration:Long)
