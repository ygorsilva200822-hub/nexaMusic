package com.nexa.music
import android.content.ComponentName
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.google.common.util.concurrent.ListenableFuture
import kotlinx.coroutines.launch
import java.util.concurrent.Executors

private val Night=Color(0xFF090910)
private val Card=Color(0xFF191624)
private val Violet=Color(0xFF9B70FF)
private val Soft=Color(0xFFAAA5B7)

class MainActivity:ComponentActivity() {
    private var future:ListenableFuture<MediaController>?=null
    private var controller:MediaController?=null
    override fun onStart() {
        super.onStart()
        future=MediaController.Builder(this,SessionToken(this,ComponentName(this,MusicService::class.java))).buildAsync()
        future?.addListener({ try { controller=future?.get() } catch (_:Exception) {} },Executors.newSingleThreadExecutor())
    }
    override fun onStop() {
        future?.let { MediaController.releaseFuture(it) }; controller=null; super.onStop()
    }
    override fun onCreate(savedInstanceState:Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { Home(
            play={ track,queue ->
                controller?.let { c ->
                    val items=queue.map { t -> MediaItem.Builder().setUri(AudiusRepository().streamUrl(t))
                        .setMediaMetadata(MediaMetadata.Builder().setTitle(t.title).setArtist(t.artist).build()).build() }
                    c.setMediaItems(items,queue.indexOfFirst { it.id==track.id }.coerceAtLeast(0),0L); c.prepare(); c.play()
                }
            },
            toggle={ controller?.let { if(it.isPlaying) it.pause() else it.play() } },
            next={controller?.seekToNextMediaItem()}, previous={controller?.seekToPreviousMediaItem()}
        ) }
    }
}

@Composable
private fun Home(play:(Track,List<Track>)->Unit,toggle:()->Unit,next:()->Unit,previous:()->Unit) {
    val repo= remember { AudiusRepository() }; val scope= rememberCoroutineScope()
    var query by remember { mutableStateOf("") }; var tracks by remember { mutableStateOf(emptyList<Track>()) }
    var favorites by remember { mutableStateOf(setOf<String>()) }; var current by remember { mutableStateOf<Track?>(null) }
    var loading by remember { mutableStateOf(false) }; var playing by remember { mutableStateOf(true) }
    var message by remember { mutableStateOf("Carregando músicas…") }
    LaunchedEffect(Unit) {
        loading=true; tracks=repo.search("electronic"); loading=false
        message=if(tracks.isEmpty()) "Não foi possível carregar. Confira sua conexão." else ""
    }
    MaterialTheme(colorScheme=darkColorScheme(primary=Violet,background=Night,surface=Card,onSurface=Color.White)) {
        Column(Modifier.fillMaxSize().background(Night).padding(horizontal=18.dp)) {
            Spacer(Modifier.height(24.dp))
            Row(verticalAlignment=Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("NEXA",color=Violet,fontSize=12.sp,fontWeight=FontWeight.Bold,letterSpacing=5.sp)
                    Text("MUSIC",color=Color.White,fontSize=30.sp,fontWeight=FontWeight.Black,letterSpacing=1.sp)
                }
                Box(Modifier.size(46.dp).clip(CircleShape).background(Card),contentAlignment=Alignment.Center) {
                    Text("N",color=Violet,fontSize=24.sp,fontWeight=FontWeight.Black)
                }
            }
            Spacer(Modifier.height(24.dp))
            Text("Sua música. Seu ritmo.",color=Color.White,fontSize=23.sp,fontWeight=FontWeight.Bold)
            Text("Descubra novos sons e artistas.",color=Soft,fontSize=13.sp)
            Spacer(Modifier.height(18.dp))
            Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(15.dp)).background(Card).padding(horizontal=12.dp),
                verticalAlignment=Alignment.CenterVertically) {
                Icon(Icons.Default.Search,null,tint=Violet)
                TextField(value=query,onValueChange={query=it},modifier=Modifier.weight(1f),
                    placeholder={Text("Buscar música ou artista",color=Soft)},singleLine=true,
                    colors=TextFieldDefaults.colors(focusedContainerColor=Card,unfocusedContainerColor=Card,
                        focusedIndicatorColor=Color.Transparent,unfocusedIndicatorColor=Color.Transparent))
                Text("IR",color=Violet,fontWeight=FontWeight.Bold,modifier=Modifier.clickable {
                    if(query.isNotBlank()) scope.launch {
                        loading=true; val result=repo.search(query.trim()); tracks=result
                        message=if(result.isEmpty()) "Nenhuma faixa encontrada." else ""; loading=false
                    }
                }.padding(8.dp))
            }
            Spacer(Modifier.height(22.dp))
            Row(verticalAlignment=Alignment.CenterVertically) {
                Text("Explorar",color=Color.White,fontSize=19.sp,fontWeight=FontWeight.Bold,modifier=Modifier.weight(1f))
                Text("MÚSICA ONLINE",color=Violet,fontSize=9.sp,fontWeight=FontWeight.Bold,letterSpacing=1.sp)
            }
            Spacer(Modifier.height(10.dp))
            if(loading) LinearProgressIndicator(Modifier.fillMaxWidth(),color=Violet)
            if(tracks.isEmpty()) Text(message,color=Soft,modifier=Modifier.padding(vertical=20.dp))
            LazyColumn(Modifier.weight(1f),contentPadding=PaddingValues(bottom=12.dp),verticalArrangement=Arrangement.spacedBy(9.dp)) {
                items(tracks,key={it.id}) { t ->
                    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(15.dp)).background(Card)
                        .clickable { current=t; play(t,tracks); playing=true }.padding(12.dp),
                        verticalAlignment=Alignment.CenterVertically) {
                        Box(Modifier.size(49.dp).clip(RoundedCornerShape(11.dp))
                            .background(Brush.linearGradient(listOf(Color(0xFF56318D),Color(0xFF201A31)))),
                            contentAlignment=Alignment.Center) { Text("♫",color=Color.White,fontSize=24.sp) }
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(t.title,color=Color.White,fontWeight=FontWeight.SemiBold,maxLines=1,overflow=TextOverflow.Ellipsis)
                            Text(t.artist,color=Soft,fontSize=12.sp,maxLines=1,overflow=TextOverflow.Ellipsis)
                        }
                        IconButton(onClick={favorites=if(t.id in favorites) favorites-t.id else favorites+t.id}) {
                            Icon(if(t.id in favorites) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                                contentDescription="Favoritar",tint=if(t.id in favorites) Violet else Soft)
                        }
                    }
                }
            }
            current?.let { t ->
                Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp))
                    .background(Brush.horizontalGradient(listOf(Color(0xFF302047),Card))).padding(6.dp),
                    verticalAlignment=Alignment.CenterVertically) {
                    Column(Modifier.weight(1f).padding(start=8.dp)) {
                        Text(t.title,color=Color.White,fontWeight=FontWeight.Bold,maxLines=1,overflow=TextOverflow.Ellipsis)
                        Text(t.artist,color=Soft,fontSize=11.sp,maxLines=1)
                    }
                    IconButton(onClick=previous) { Icon(Icons.Default.SkipPrevious,null,tint=Color.White) }
                    IconButton(onClick={toggle();playing=!playing}) { Icon(if(playing) Icons.Default.Pause else Icons.Default.PlayArrow,null,tint=Violet) }
                    IconButton(onClick=next) { Icon(Icons.Default.SkipNext,null,tint=Color.White) }
                }
            }
            Text("Nexa Music  •  artistas independentes",color=Color(0xFF777184),fontSize=10.sp,
                modifier=Modifier.align(Alignment.CenterHorizontally).padding(vertical=10.dp))
        }
    }
}
