# Nexa Music — versão online (MVP)

Aplicativo Android de streaming e descoberta musical usando a API pública Audius.

## O que esta versão inclui
- Busca online por música/artista
- Filtros de gênero (a busca usa o nome do gênero)
- Reprodução, pausa e navegação de faixas
- Favoritos mantidos enquanto o app está aberto
- Capas quando o catálogo fornece artwork

## Limites importantes
O catálogo vem do Audius, não do Spotify. A disponibilidade de funk, sertanejo e outros estilos depende das faixas publicadas e acessíveis nesse catálogo. Não promete todas as músicas comerciais. Use somente conteúdo disponibilizado para streaming pela plataforma e respeite os direitos dos titulares.

Este é um MVP de código-fonte. A compilação no GitHub Actions e o funcionamento em aparelho real ainda precisam ser testados. Esta versão inicial não implementa conta, playlists persistentes ou reprodução em segundo plano garantida.
