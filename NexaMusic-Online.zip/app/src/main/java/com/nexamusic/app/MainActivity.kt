package com.nexamusic.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.lifecycleScope
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import coil.compose.AsyncImage
import kotlinx.coroutines.launch

private val Bg = Color(0xFF090910)
private val Panel = Color(0xFF171725)
private val Purple = Color(0xFF9B5CFF)
private val Muted = Color(0xFFAAA8B8)

class MainActivity : ComponentActivity() {
    private var player: ExoPlayer? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        player = ExoPlayer.Builder(this).build()
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(
                background = Bg, surface = Panel, primary = Purple,
                onBackground = Color.White, onSurface = Color.White
            )) {
                NexaScreen(
                    onPlay = { track -> play(track) },
                    onToggle = { player?.let { if (it.isPlaying) it.pause() else it.play() } },
                    onNext = { player?.seekToNextMediaItem() },
                    onPrevious = { player?.seekToPreviousMediaItem() },
                    isPlaying = { player?.isPlaying == true }
                )
            }
        }
    }

    private fun play(track: Track) {
        val p = player ?: return
        p.setMediaItem(MediaItem.Builder().setUri(track.streamUrl).setMediaId(track.id)
            .setMediaMetadata(androidx.media3.common.MediaMetadata.Builder()
                .setTitle(track.title).setArtist(track.artist).build()).build())
        p.prepare()
        p.play()
    }

    override fun onDestroy() {
        player?.release()
        player = null
        super.onDestroy()
    }
}

@Composable
private fun NexaScreen(
    onPlay: (Track) -> Unit,
    onToggle: () -> Unit,
    onNext: () -> Unit,
    onPrevious: () -> Unit,
    isPlaying: () -> Boolean
) {
    var query by remember { mutableStateOf("funk") }
    var selectedGenre by remember { mutableStateOf("Funk") }
    var tracks by remember { mutableStateOf<List<Track>>(emptyList()) }
    var favorites by remember { mutableStateOf(setOf<String>()) }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var current by remember { mutableStateOf<Track?>(null) }
    var playing by remember { mutableStateOf(false) }

    val genres = listOf("Funk", "Sertanejo", "Trap", "Rap", "Pagode", "Gospel", "Pop", "Rock", "Eletrônica", "Forró", "MPB", "Reggae")

    fun load(term: String) {
        loading = true
        error = null
        // LaunchedEffect below observes this key and performs the request.
        query = term
    }

    LaunchedEffect(query) {
        loading = true
        error = null
        try {
            tracks = AudiusApi.search(query)
            if (tracks.isEmpty()) error = "Não encontramos faixas para essa busca. Tente outro termo."
        } catch (e: Exception) {
            error = "Não foi possível carregar o catálogo. Verifique sua internet e tente novamente."
        } finally { loading = false }
    }

    Column(Modifier.fillMaxSize().background(Bg).padding(horizontal = 18.dp)) {
        Spacer(Modifier.height(22.dp))
        Text("NEXA", color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Bold, letterSpacing = 5.sp)
        Text("MUSIC", color = Purple, fontSize = 34.sp, fontWeight = FontWeight.ExtraBold)
        Text("Sua trilha. Seu ritmo.", color = Muted, fontSize = 14.sp)
        Spacer(Modifier.height(22.dp))

        Row(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(14.dp)).padding(14.dp),
            verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.Search, null, tint = Purple)
            Spacer(Modifier.width(10.dp))
            BasicTextField(value = query, onValueChange = { query = it },
                modifier = Modifier.weight(1f), singleLine = true,
                textStyle = androidx.compose.ui.text.TextStyle(color = Color.White, fontSize = 15.sp),
                decorationBox = { inner ->
                    if (query.isEmpty()) Text("Buscar músicas ou artistas", color = Muted)
                    inner()
                })
            Text("BUSCAR", color = Purple, fontWeight = FontWeight.Bold,
                modifier = Modifier.clickable { load(query) }.padding(start = 8.dp))
        }

        Spacer(Modifier.height(20.dp))
        Text("EXPLORE GÊNEROS", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
        Spacer(Modifier.height(10.dp))
        androidx.compose.foundation.lazy.LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            items(genres) { genre ->
                FilterChip(selected = selectedGenre == genre, onClick = {
                    selectedGenre = genre
                    query = genre.lowercase()
                }, label = { Text(genre) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = Purple, selectedLabelColor = Color.White
                    ))
            }
        }
        Spacer(Modifier.height(18.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("PARA OUVIR", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.weight(1f))
            if (loading) CircularProgressIndicator(modifier = Modifier.size(18.dp), color = Purple, strokeWidth = 2.dp)
        }
        Spacer(Modifier.height(10.dp))

        if (error != null) {
            Text(error!!, color = Muted, modifier = Modifier.padding(vertical = 18.dp))
        }
        LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(tracks, key = { it.id }) { track ->
                Row(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(12.dp))
                    .clickable { current = track; onPlay(track); playing = true }
                    .padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                    AsyncImage(model = track.artwork, contentDescription = null,
                        modifier = Modifier.size(54.dp).background(Color(0xFF302044), RoundedCornerShape(8.dp)))
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(track.title, color = Color.White, fontWeight = FontWeight.SemiBold, maxLines = 1)
                        Text(track.artist, color = Muted, fontSize = 12.sp, maxLines = 1)
                    }
                    IconButton(onClick = {
                        favorites = if (favorites.contains(track.id)) favorites - track.id else favorites + track.id
                    }) {
                        Icon(if (favorites.contains(track.id)) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                            null, tint = if (favorites.contains(track.id)) Purple else Muted)
                    }
                }
            }
        }
        current?.let { track ->
            Column(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp))
                .padding(14.dp)) {
                Text("TOCANDO AGORA", color = Purple, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                Text(track.title, color = Color.White, fontWeight = FontWeight.Bold, maxLines = 1)
                Text(track.artist, color = Muted, fontSize = 12.sp, maxLines = 1)
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = onPrevious) { Icon(Icons.Default.SkipPrevious, null, tint = Color.White) }
                    IconButton(onClick = { onToggle(); playing = !playing }) {
                        Icon(if (playing) Icons.Default.Pause else Icons.Default.PlayArrow, null,
                            tint = Purple, modifier = Modifier.size(38.dp))
                    }
                    IconButton(onClick = onNext) { Icon(Icons.Default.SkipNext, null, tint = Color.White) }
                }
            }
        }
        Spacer(Modifier.height(12.dp))
    }
}
