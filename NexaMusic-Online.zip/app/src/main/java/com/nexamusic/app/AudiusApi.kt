package com.nexamusic.app

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.net.URLEncoder
import java.util.concurrent.TimeUnit

object AudiusApi {
    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(25, TimeUnit.SECONDS)
        .build()
    private const val BASE = "https://api.audius.co/v1"

    suspend fun search(term: String): List<Track> = withContext(Dispatchers.IO) {
        val encoded = URLEncoder.encode(term, "UTF-8")
        val json = get("$BASE/tracks/search?query=$encoded&limit=30")
        val arr = json.optJSONArray("data") ?: return@withContext emptyList()
        buildList {
            for (i in 0 until arr.length()) {
                val item = arr.optJSONObject(i) ?: continue
                val id = item.optString("id")
                if (id.isBlank() || id == "null") continue
                val user = item.optJSONObject("user")
                val artworkObj = item.optJSONObject("artwork")
                val art = artworkObj?.optString("150x150")?.takeIf { !it.isNullOrBlank() && it != "null" }
                    ?: artworkObj?.optString("480x480")?.takeIf { !it.isNullOrBlank() && it != "null" }
                val stream = "$BASE/tracks/${URLEncoder.encode(id, "UTF-8")}/stream"
                add(Track(id, item.optString("title", "Sem título"),
                    user?.optString("name") ?: "Artista desconhecido", art, stream))
            }
        }
    }

    private fun get(url: String): JSONObject {
        val request = Request.Builder().url(url).header("Accept", "application/json").build()
        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) error("Serviço de música respondeu ${response.code}")
            return JSONObject(response.body?.string() ?: "{}")
        }
    }
}
